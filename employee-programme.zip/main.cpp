
#include <iostream>
using namespace std;
class employee
{
public:
char designation[30],name[30];
int age;
int salary;

    void getdata()
    {

        cout<<" Enter name of employee  ";
        cin>>name;
        cout<<"Enter age of employee ";
        cin>>age;
        cout<<"Salary of employee ";
        cin>>salary;
        cout<<" designation of employee ";
        cin>>designation;
    }
};
int main()
{
    int i;
    employee e1 [3];
    for (i=0;i<3;i++)
    {
    e1[i].getdata();
    }
    
    
    return 0;
}
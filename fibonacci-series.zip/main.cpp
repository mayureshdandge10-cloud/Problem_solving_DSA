
#include <iostream>
using namespace std;
int main()
{
    int b;
    cout<<"no of elements you want to print ";
    cin>>b;
    int i,a[b];
    a[0]=0;
    a[1]=1;
    for(i=0;i<b-2;i++)
    {
        a[i+2]=a[i+1]+a[i];
    }
    for(i=0;i<b;i++)
    {
        cout<<a[i]<<endl;
    }

    return 0;
}
#include <iostream>
using namespace std;

int main()
{
    char a;
    float F,C,b,d;
 
 cout<<" Enter C to convert from celsius to fahrenheit  ";
 cout<< "Enter F to convert from fahrenheit to celsius ";
 cin>>a;
 if(a=='c'||a=='C')
 {
     cout<<"Enter celsius ";
     cin>>b;
     F=b*1.8+32;
     cout<<"Value in fahrenheit is "<<F<<endl;
     
 }
 else
{
    cout<<"Enter fahrenheit ";
     cin>>d;
    C=(d-32)*5/9;
    cout<<"Value in celsius is "<<C<<endl;

}
    return 0;
};
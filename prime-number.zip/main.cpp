
#include <iostream>
using namespace std;
int main()
{
int a,i,m=0,b,n=0;
	cout<<"Enter number ";
	cin>>a;
	for ( i=2; i<a; i++)
	{
		b=a%i;
		if(b==0)
		{
		    m=n+1;
		}
	}
	
	if(m==n)
	{
		cout<<"Number is prime ";
	}
	else
	{
		cout<<"Number is composite ";
	}

	return 0;
}